package targil0;

public class Payroll {

	public static void main(String[] args) {
		
		try {
			HourlyEmployee he = new HourlyEmployee("Ariel","David",111,10,100);
			CommissionEmployee ce = new CommissionEmployee("Malachi","David",222,20000,20);
			BasePlusCommissionEmployee bpce = new BasePlusCommissionEmployee("Meitav","David",333,300,30, 1000);
		
		
			Employee[] e_array = {he,ce,bpce};
	    
			for  (Employee e : e_array) {
				
				System.out.println(e);
			
				if( e.getId() == bpce.getId() ){ System.out.println("weakly salary: " + e.earnings()*1.1); } 
			 
				else { System.out.println("weakly salary: " + e.earnings());}
			}
			
		}catch(IllegalArgumentException e) {
			System.out.println(e);
		}
	}
}
